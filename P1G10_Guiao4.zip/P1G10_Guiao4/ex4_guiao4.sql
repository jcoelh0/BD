
CREATE SCHEMA  PRESCRI�AO_MEDICAMENTOS
go


CREATE TABLE PRESCRI�AO_MEDICAMENTOS.MEDICO (
	n_medico		INT,
	especialidade	VARCHAR(30),
	nome			VARCHAR(30) NOT NULL,
	PRIMARY KEY(n_medico)
);

CREATE TABLE PRESCRI�AO_MEDICAMENTOS.PACIENTE (
	n_utente			INT,
	endere�o			VARCHAR(30),
	data_nascimento		DATE NOT NULL,
	nome				VARCHAR(30) NOT NULL,
	PRIMARY KEY(n_utente)
);

CREATE TABLE PRESCRI�AO_MEDICAMENTOS.FARMACIA (
	nome		VARCHAR(30) NOT NULL,
	endere�o	VARCHAR(30),
	telefone	INT,
	PRIMARY KEY(nome)
);

CREATE TABLE PRESCRI�AO_MEDICAMENTOS.PRESCRI�AO (
	n_prescricao	INT,
	n_medico		INT,
	n_utente		INT,
	data_presc		DATE NOT NULL,
	nome_farmacia	VARCHAR(30),
	PRIMARY KEY(n_prescricao),
	FOREIGN KEY(n_medico) REFERENCES PRESCRI�AO_MEDICAMENTOS.MEDICO(n_medico),
	FOREIGN KEY(n_utente) REFERENCES PRESCRI�AO_MEDICAMENTOS.PACIENTE(n_utente),
	FOREIGN KEY(nome_farmacia) REFERENCES PRESCRI�AO_MEDICAMENTOS.FARMACIA(nome)
);

CREATE TABLE PRESCRI�AO_MEDICAMENTOS.FARMACEUTICA (
	n_registo	INT,
	nome		VARCHAR(30) NOT NULL,
	endereco	VARCHAR(30) NOT NULL,
	PRIMARY KEY(n_registo),
);

CREATE TABLE PRESCRI�AO_MEDICAMENTOS.FARMACO (
	formula			VARCHAR(30),
	nome_comercial	INT NOT NULL,
	n_registo_farm	INT,
	PRIMARY KEY(n_registo_farm, nome_comercial),
	FOREIGN KEY(nome_comercial) REFERENCES PRESCRI�AO_MEDICAMENTOS.FARMACEUTICA(n_registo)
);

CREATE TABLE PRESCRI�AO_MEDICAMENTOS.CONTEM (
	n_prescricao	INT,
	n_registo		INT,
	nome_comercial	INT,
	PRIMARY KEY(n_prescricao, n_registo, nome_comercial),
	FOREIGN KEY(n_prescricao) REFERENCES PRESCRI�AO_MEDICAMENTOS.PRESCRI�AO(n_prescricao),
	FOREIGN KEY(n_registo, nome_comercial) 
	REFERENCES PRESCRI�AO_MEDICAMENTOS.FARMACO(n_registo_farm, nome_comercial)
);

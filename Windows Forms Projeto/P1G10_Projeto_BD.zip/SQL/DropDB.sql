drop table STAND.FAZ;
drop table STAND.LEVA;
drop table STAND.COMPRA;
drop table STAND.OFICINA;
drop table STAND.STAND;
drop table STAND.MECANICO;
drop table STAND.CLIENTE;
drop table STAND.VEICULO_REPARAR;
drop table STAND.VEICULO_VENDA;
drop table STAND.PECAS;
drop table STAND.TIPO_PECA;
drop table STAND.TIPO_VEICULO;

drop schema STAND;